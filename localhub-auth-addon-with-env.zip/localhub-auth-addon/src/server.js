const express = require('express');
const connectDb = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const adminVendorRoutes = require('./routes/adminVendorRoutes');
const vendorRoutes = require('./routes/vendorRoutes.example');
const errorHandler = require('./middleware/errorHandler');
const { successResponse } = require('./utils/apiResponse');
const env = require('./config/env');

const app = express();

app.use(express.json());

app.get('/health', (req, res) => successResponse(res, 'Server is running'));
app.use('/auth', authRoutes);
app.use('/admin', adminVendorRoutes);
app.use('/vendor', vendorRoutes);
app.use(errorHandler);

async function startServer() {
  await connectDb();
  app.listen(env.port, () => {
    console.log(`Server running on port ${env.port}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error.message);
  process.exit(1);
});
