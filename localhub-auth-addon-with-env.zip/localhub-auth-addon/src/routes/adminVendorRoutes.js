const express = require('express');
const {
  getPendingVendors,
  approveVendor,
  rejectVendor
} = require('../controllers/adminVendorController');
const verifyToken = require('../middleware/verifyToken');
const authorize = require('../middleware/authorize');

const router = express.Router();

router.use(verifyToken, authorize('admin'));
router.get('/vendors/pending', getPendingVendors);
router.patch('/vendors/:id/approve', approveVendor);
router.patch('/vendors/:id/reject', rejectVendor);

module.exports = router;
