const express = require('express');
const verifyToken = require('../middleware/verifyToken');
const authorize = require('../middleware/authorize');
const ensureApprovedVendor = require('../middleware/ensureApprovedVendor');
const { successResponse } = require('../utils/apiResponse');

const router = express.Router();

router.get(
  '/dashboard',
  verifyToken,
  authorize('vendor'),
  ensureApprovedVendor,
  (req, res) => successResponse(res, 'Vendor dashboard fetched successfully', { user: req.user })
);

module.exports = router;
