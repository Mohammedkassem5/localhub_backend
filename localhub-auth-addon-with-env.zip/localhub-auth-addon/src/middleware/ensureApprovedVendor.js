const { errorResponse } = require('../utils/apiResponse');

function ensureApprovedVendor(req, res, next) {
  if (req.user?.role === 'vendor' && req.user?.status !== 'approved') {
    return errorResponse(res, 'Your vendor account is pending approval', 403);
  }

  return next();
}

module.exports = ensureApprovedVendor;
