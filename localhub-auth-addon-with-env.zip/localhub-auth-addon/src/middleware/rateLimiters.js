const rateLimit = require('express-rate-limit');
const env = require('../config/env');

const authLoginLimiter = rateLimit({
  windowMs: env.rateLimitWindowMs,
  max: env.rateLimitMaxRequests,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many login attempts, please try again later'
  }
});

module.exports = {
  authLoginLimiter
};
