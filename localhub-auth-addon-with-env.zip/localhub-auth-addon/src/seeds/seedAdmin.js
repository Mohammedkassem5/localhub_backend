const connectDb = require('../config/db');
const env = require('../config/env');
const User = require('../models/User');

async function seedAdmin() {
  try {
    await connectDb();

    const existingAdmin = await User.findOne({ email: env.adminEmail.toLowerCase() });
    if (existingAdmin) {
      console.log('Admin user already exists');
      process.exit(0);
    }

    await User.create({
      name: env.adminName,
      email: env.adminEmail.toLowerCase(),
      password: env.adminPassword,
      role: 'admin',
      status: 'approved'
    });

    console.log('Admin user created successfully');
    process.exit(0);
  } catch (error) {
    console.error('Failed to seed admin user:', error.message);
    process.exit(1);
  }
}

seedAdmin();
