const mongoose = require('mongoose');
const env = require('./env');

async function connectDb() {
  if (!env.mongoUrl) {
    throw new Error('MONGO_URL is missing in environment variables');
  }

  await mongoose.connect(env.mongoUrl);
  console.log('MongoDB connected');
}

module.exports = connectDb;
