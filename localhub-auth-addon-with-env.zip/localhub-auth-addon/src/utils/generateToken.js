const jwt = require('jsonwebtoken');
const env = require('../config/env');

function generateAccessToken(user) {
  return jwt.sign(
    {
      id: user._id,
      role: user.role,
      status: user.status
    },
    env.jwtSecret,
    { expiresIn: env.jwtExpiresIn }
  );
}

module.exports = {
  generateAccessToken
};
