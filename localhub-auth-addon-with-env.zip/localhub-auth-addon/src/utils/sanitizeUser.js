function sanitizeUser(user) {
  if (!user) return null;

  const obj = typeof user.toObject === 'function' ? user.toObject() : { ...user };
  delete obj.password;
  delete obj.password_hash;
  return obj;
}

module.exports = sanitizeUser;
