const User = require('../models/User');
const { successResponse, errorResponse } = require('../utils/apiResponse');
const { generateAccessToken } = require('../utils/generateToken');
const sanitizeUser = require('../utils/sanitizeUser');

async function register(req, res, next) {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      return errorResponse(res, 'Name, email and password are required', 400);
    }

    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return errorResponse(res, 'Email already exists', 409);
    }

    const safeRole = ['vendor', 'customer'].includes(role) ? role : 'customer';

    const user = await User.create({
      name,
      email: email.toLowerCase(),
      password,
      role: safeRole
    });

    return successResponse(
      res,
      safeRole === 'vendor' ? 'Vendor registered successfully and is pending approval' : 'Registration successful',
      { user: sanitizeUser(user) },
      201
    );
  } catch (error) {
    return next(error);
  }
}

async function login(req, res, next) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return errorResponse(res, 'Email and password are required', 400);
    }

    const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
    if (!user) {
      return errorResponse(res, 'Invalid credentials', 401);
    }

    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return errorResponse(res, 'Invalid credentials', 401);
    }

    if (user.role === 'vendor' && user.status !== 'approved') {
      return errorResponse(res, 'Your vendor account is pending approval', 403);
    }

    const token = generateAccessToken(user);

    return successResponse(res, 'Login successful', {
      token,
      user: sanitizeUser(user)
    });
  } catch (error) {
    return next(error);
  }
}

async function getMe(req, res, next) {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return errorResponse(res, 'User not found', 404);
    }

    return successResponse(res, 'Profile fetched successfully', {
      user: sanitizeUser(user)
    });
  } catch (error) {
    return next(error);
  }
}

module.exports = {
  register,
  login,
  getMe
};
