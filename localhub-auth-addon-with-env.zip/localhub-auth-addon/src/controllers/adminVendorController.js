const mongoose = require('mongoose');
const User = require('../models/User');
const { successResponse, errorResponse } = require('../utils/apiResponse');
const sanitizeUser = require('../utils/sanitizeUser');

async function getPendingVendors(req, res, next) {
  try {
    const vendors = await User.find({
      role: 'vendor',
      status: 'pending'
    }).sort({ createdAt: -1 });

    return successResponse(res, 'Pending vendors fetched successfully', {
      vendors: vendors.map(sanitizeUser)
    });
  } catch (error) {
    return next(error);
  }
}

async function approveVendor(req, res, next) {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return errorResponse(res, 'Invalid vendor id', 400);
    }

    const vendor = await User.findOneAndUpdate(
      { _id: id, role: 'vendor' },
      { status: 'approved' },
      { new: true }
    );

    if (!vendor) {
      return errorResponse(res, 'Vendor not found', 404);
    }

    return successResponse(res, 'Vendor approved successfully', {
      vendor: sanitizeUser(vendor)
    });
  } catch (error) {
    return next(error);
  }
}

async function rejectVendor(req, res, next) {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return errorResponse(res, 'Invalid vendor id', 400);
    }

    const vendor = await User.findOneAndUpdate(
      { _id: id, role: 'vendor' },
      { status: 'rejected' },
      { new: true }
    );

    if (!vendor) {
      return errorResponse(res, 'Vendor not found', 404);
    }

    return successResponse(res, 'Vendor rejected successfully', {
      vendor: sanitizeUser(vendor)
    });
  } catch (error) {
    return next(error);
  }
}

module.exports = {
  getPendingVendors,
  approveVendor,
  rejectVendor
};
