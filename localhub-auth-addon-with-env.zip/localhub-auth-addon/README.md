# LocalHub Auth Add-on

Clean Express + Mongoose add-on for:
- JWT authentication
- verifyToken middleware
- role-based authorization
- vendor approval workflow
- rate limiting on `/auth/login`
- unified API response shape
- admin seed script
- Postman collection

## Important Security Note
The MongoDB connection string shared earlier should be treated as compromised and rotated immediately.
Do not commit real secrets to Git.

## Install
```bash
npm install
cp .env.example .env
npm run dev
```

## Routes
### Auth
- `POST /auth/register`
- `POST /auth/login`
- `GET /auth/me`

### Admin Vendor Approval
- `GET /admin/vendors/pending`
- `PATCH /admin/vendors/:id/approve`
- `PATCH /admin/vendors/:id/reject`

## Default Roles
- `admin`
- `vendor`
- `customer`

## Vendor Status Flow
`pending -> approved | rejected`

Vendor users cannot access vendor-only routes until they are approved.

## Response Format
Success:
```json
{
  "success": true,
  "message": "Login successful",
  "data": {}
}
```

Error:
```json
{
  "success": false,
  "message": "Invalid credentials"
}
```

## Merge Notes
This package is structured as a plug-in/add-on. If you already have a backend:
1. Copy `src/*` into your project.
2. Mount routes from `src/routes`.
3. Add env vars from `.env.example`.
4. Run the seed script once to create the admin.
